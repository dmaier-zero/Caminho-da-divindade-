import 'package:flutter/material.dart';

void main() => runApp(CaminhoDivinoApp());

class CaminhoDivinoApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Caminho Divino',
      theme: ThemeData(primarySwatch: Colors.deepPurple),
      home: Scaffold(
        appBar: AppBar(title: Text('Caminho Divino')),
        body: Center(child: Text('Bem-vindo ao Caminho Divino!')),
      ),
    );
  }
}
